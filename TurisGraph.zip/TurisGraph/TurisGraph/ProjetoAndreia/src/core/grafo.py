class Grafo:
    def __init__(self):
        # Dicionário onde a chave é a cidade e o valor é uma lista de tuplas (vizinho, peso)
        self.adjacencia = {}

    def adicionar_vertice(self, cidade):
        if cidade not in self.adjacencia:
            self.adjacencia[cidade] = []

    def adicionar_aresta(self, u, v, peso):
        # Como o grafo é não-dirigido, adicionamos nos dois sentidos
        self.adicionar_vertice(u)
        self.adicionar_vertice(v)
        self.adjacencia[u].append((v, peso))
        self.adjacencia[v].append((u, peso))