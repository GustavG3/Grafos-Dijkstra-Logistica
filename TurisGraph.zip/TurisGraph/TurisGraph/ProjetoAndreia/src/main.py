import os
import sys

# Adiciona a pasta atual ao caminho para o Python achar os módulos 'core', 'infra', etc.
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.grafo import Grafo
from infra.file_reader import carregar_grafo_json
from algorithms.dijkstra import executar_dijkstra

def main():
    # 1. Instancia o Grafo
    meu_grafo = Grafo() 
    
    # 2. Define o caminho para o mapa na mesma pasta do main.py
    diretorio_atual = os.path.dirname(os.path.abspath(__file__))
    caminho_mapa = os.path.join(diretorio_atual, 'mapa.json')
    
    # 3. Carregar os dados do JSON
    carregar_grafo_json(caminho_mapa, meu_grafo)
    
    # Verifica se o grafo foi carregado
    if not meu_grafo.adjacencia:
        print(f"[ERRO]: Nenhum dado carregado. Verifique se o arquivo existe em: {caminho_mapa}")
        return

    # Exibe as cidades disponíveis
    print("\nCidades carregadas no sistema:")
    for cidade in meu_grafo.adjacencia:
        print(f"- {cidade}")

    print("\n--- Planejador de Rotas TurisGraph ---")
    origem = input("Digite a cidade de partida: ")
    destino = input("Digite a cidade de destino: ")

    # 4. Execução do Algoritmo de Dijkstra
    resultado = executar_dijkstra(meu_grafo, origem, destino)

    # 5. Exibição do Resultado Detalhado (Corrigindo a Identação)
    if resultado:
        caminho, custo = resultado #
        print("\n" + "="*40)
        print("✅ ROTA ENCONTRADA COM SUCESSO")
        print("="*40)
        
        # Mostra a trajetória completa
        print(f"📍 Trajetória: {' ➔ '.join(caminho)}")
        
        print(f"📏 Distância Total: {custo} km")
        print(f"🏁 Total de estados percorridos: {len(caminho)}")
        print("="*40)
    else:
        print("\n❌ [AVISO]: Não foi possível encontrar uma rota entre essas cidades.")

if __name__ == "__main__":
    main()