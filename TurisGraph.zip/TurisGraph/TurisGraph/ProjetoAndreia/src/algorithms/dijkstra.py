import heapq

def executar_dijkstra(grafo, inicio, fim):
    if inicio not in grafo.adjacencia or fim not in grafo.adjacencia:
        return None

    distancias = {vertice: float('inf') for vertice in grafo.adjacencia}
    distancias[inicio] = 0
    pq = [(0, inicio)]
    predecessores = {vertice: None for vertice in grafo.adjacencia}

    while pq:
        dist_atual, u = heapq.heappop(pq)

        if u == fim:
            break
        if dist_atual > distancias[u]:
            continue

        for v, peso in grafo.adjacencia[u]:
            distancia = dist_atual + peso
            if distancia < distancias[v]:
                distancias[v] = distancia
                predecessores[v] = u
                heapq.heappush(pq, (distancia, v))

    # Reconstruir o caminho para a saída ser legível (Exigência do E3)
    caminho = []
    atual = fim
    while atual is not None:
        caminho.insert(0, atual)
        atual = predecessores[atual]

    if distancias[fim] == float('inf'):
        return None
        
    return caminho, distancias[fim] # Agora retorna (lista, valor)