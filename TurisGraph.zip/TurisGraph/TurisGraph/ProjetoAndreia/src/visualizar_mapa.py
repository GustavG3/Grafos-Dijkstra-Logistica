import json
import networkx as nx
import matplotlib.pyplot as plt

def gerar_visualizacao():
    # 1. Carregar os dados do seu JSON
    try:
        with open('mapa.json', 'r', encoding='utf-8') as f:
            dados = json.load(f)
    except FileNotFoundError:
        print("Erro: Certifique-se de que o arquivo 'mapa.json' está na mesma pasta.")
        return

    # 2. Criar o objeto do Grafo
    G = nx.Graph()

    # 3. Adicionar as conexões (arestas) e pesos
    for aresta in dados['arestas']:
        G.add_edge(aresta['origem'], aresta['destino'], weight=aresta['peso'])

    # 4. Configurar o layout (posicionamento dos nós)
    plt.figure(figsize=(15, 10))
    # O spring_layout tenta espalhar os nós de forma que não fiquem um em cima do outro
    pos = nx.spring_layout(G, k=0.5, iterations=50)

    # 5. Desenhar os elementos
    nx.draw(G, pos, 
            with_labels=True, 
            node_color='skyblue', 
            node_size=3000, 
            font_size=9, 
            font_weight='bold', 
            edge_color='gray',
            width=1.5)

    # Desenhar os pesos (distâncias) em cima das linhas
    labels = nx.get_edge_attributes(G, 'weight')
    nx.draw_networkx_edge_labels(G, pos, edge_labels=labels, font_size=8)

    plt.title("TurisGraph - Mapa de Conexões entre Estados Brasileiros", fontsize=15)
    plt.axis('off') # Esconde os eixos X e Y
    
    print("Gerando visualização... Uma janela será aberta.")
    plt.show()

if __name__ == "__main__":
    gerar_visualizacao()