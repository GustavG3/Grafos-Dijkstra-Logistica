import json

def carregar_grafo_json(caminho, grafo):
    try:
        with open(caminho, 'r', encoding='utf-8') as f:
            dados = json.load(f)
            for aresta in dados['arestas']:
                # Ajuste os nomes das chaves conforme seu mapa.json do E2
                grafo.adicionar_aresta(aresta['origem'], aresta['destino'], aresta['peso'])
    except FileNotFoundError:
        print(f"\n[ERRO]: O arquivo não foi encontrado em: {caminho}")
    except Exception as e:
        print(f"\n[ERRO]: Falha ao ler o JSON: {e}")