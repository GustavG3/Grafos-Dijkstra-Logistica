import unittest
from core.grafo import Grafo
from algorithms.dijkstra import calcular_dijkstra

class TestDijkstra(unittest.TestCase):
    def setUp(self):
        self.grafo = Grafo()

    def test_caso_base(self):
        # Entrada válida com resultado conhecido [cite: 36]
        self.grafo.adicionar_aresta("A", "B", 5)
        self.grafo.adicionar_aresta("B", "C", 10)
        distancia, caminho = calcular_dijkstra(self.grafo, "A", "C")
        self.assertEqual(distancia, 15)
        self.assertEqual(caminho, ["A", "B", "C"])

    def test_grafo_vazio(self):
        # Comportamento com entrada vazia ou nula [cite: 36]
        # Tentando buscar em um grafo sem arestas
        self.grafo.adicionar_vertice("A")
        self.grafo.adicionar_vertice("B")
        distancia, caminho = calcular_dijkstra(self.grafo, "A", "B")
        self.assertEqual(distancia, float('inf'))

    def test_grafo_completo(self):
        # Todos os vértices conectados entre si [cite: 36]
        self.grafo.adicionar_aresta("A", "B", 10)
        self.grafo.adicionar_aresta("B", "C", 2)
        self.grafo.adicionar_aresta("A", "C", 1) # Caminho direto é mais curto
        distancia, caminho = calcular_dijkstra(self.grafo, "A", "B")
        # O caminho mais curto de A para B deve ser A->C->B (1+2=3)
        self.assertEqual(distancia, 3)

if __name__ == '__main__':
    unittest.main()