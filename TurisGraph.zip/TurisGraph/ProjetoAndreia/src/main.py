import os
import sys

# Adiciona a pasta 'src' ao caminho de busca do Python para evitar erros de importação
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.grafo import Grafo
from infra.file_reader import carregar_grafo_json
from algorithms.dijkstra import executar_dijkstra

def main():
    # 1. Instancia o Grafo (Camada de Domínio) [cite: 20]
    meu_grafo = Grafo() 
    
    # 2. Gerenciamento de Caminho Robusto (Evita erro de 'Arquivo não encontrado')
    diretorio_atual = os.path.dirname(os.path.abspath(__file__))
    # Ajuste: busca a pasta 'data' que está um nível acima da 'src'
    caminho_mapa = os.path.join(diretorio_atual, '..', 'data', 'mapa.json')
    
    # 3. Carregar os dados (Camada de Infraestrutura) [cite: 22, 28]
    carregar_grafo_json(caminho_mapa, meu_grafo)
    
    # Exibe as cidades para provar que o arquivo foi lido (Requisito de visibilidade do MVP) [cite: 31]
    if not meu_grafo.adjacencia:
        print(f"[ERRO]: Nenhum dado carregado. Verifique se o arquivo existe em: {caminho_mapa}")
        return

    print("\nCidades carregadas no sistema:")
    for cidade in meu_grafo.adjacencia:
        print(f"- {cidade}")

    print("\n--- Planejador de Rotas TurisGraph ---")
    origem = input("Digite a cidade de partida: ")
    destino = input("Digite a cidade de destino: ")

    # 4. Execução do Algoritmo Principal (Dijkstra) [cite: 21, 27]
    resultado = executar_dijkstra(meu_grafo, origem, destino)

    # 5. Exibição do Resultado (Saída legível exigida no E3) [cite: 31]
    if resultado:
        caminho, custo = resultado
        print(f"\n>>> Melhor rota encontrada: {' -> '.join(caminho)}")
        print(f">>> Custo total da viagem: {custo}")
    else:
        print("\n[AVISO]: Não foi possível encontrar uma rota entre essas cidades.")

if __name__ == "__main__":
    main()